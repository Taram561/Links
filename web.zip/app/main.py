#!/usr/bin/python3
from flask import Flask, make_response, request, render_template, render_template_string as render, redirect
import urllib.parse

template_name = "index.html"
app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    input_text = request.form.get("input_text", "")
    output_text = None
    mode = "encode"
    html = open(template_name).read()
    if request.method == "POST":
        mode = request.form.get("mode", "encode")
        if "encode" in mode:
            output_text = urllib.parse.quote(input_text)
            html = render(html, input_text=input_text, output_text=output_text, mode=mode)
        if "decode" in mode:
            output_text = urllib.parse.unquote(input_text)
            html = render(html, input_text=input_text, output_text=output_text, mode=mode)
        return make_response(html)
    return make_response(render(html))


if __name__ == "__main__":
    app.run(host='0.0.0.0')